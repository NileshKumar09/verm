USE [EmployeeMgmt]
GO

CREATE PROCEDURE [dbo].[SelectEmployees]
AS
BEGIN
select * from Employee
END
GO


