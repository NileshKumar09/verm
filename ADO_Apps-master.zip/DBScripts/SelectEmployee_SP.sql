USE [EmployeeMgmt]
GO

Create PROCEDURE [dbo].[SelectEmployee]
@ID int,
@Name varchar(50) output,
@Designation int output,
@Department int output
AS
BEGIN
	select @Name = Name, @Designation = Designation, @Department = Department
	from Employee where Id = @ID
END
GO


