USE [EmployeeMgmt]
GO


Create PROCEDURE [dbo].[InsertEmployee]
@ID int,
@Name varchar(50),
@Designation int,
@Department int
AS
BEGIN
	insert into Employee values(@ID, @Name, @Designation, @Department)
END

GO


