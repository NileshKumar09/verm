USE [EmployeeMgmt]
GO

Create PROCEDURE [dbo].[DeleteEmployee]
@ID int
AS
BEGIN
	delete Employee where ID = @ID
END

GO


