USE [EmployeeMgmt]
GO

Create PROCEDURE [dbo].[UpdateEmployee]
@ID int,
@Name varchar(50),
@Designation int,
@Department int
AS
BEGIN
	update Employee set Name = @Name,Designation = @Designation, Department = @Department where ID = @ID
END

GO


