﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRDS.Entities;
using HRDS.Exceptions;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace HRDS.DataAccessLayer
{
    public class EmployeeDAL
    {
        public bool AddEmployeeDAL(Employee objEmployee)
        {
            bool employeeAdded = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HRDSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009519].[InsertEmployee_9519]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Id = new SqlParameter("@ID", objEmployee.Id);
                SqlParameter objSqlParam_Name = new SqlParameter("@Name", objEmployee.Name);
                SqlParameter objSqlParam_Designation = new SqlParameter("@Designation", objEmployee.Designation);
                SqlParameter objSqlParam_Department = new SqlParameter("@Department", objEmployee.Department);
                //
                objCom.Parameters.Add(objSqlParam_Id);
                objCom.Parameters.Add(objSqlParam_Name);
                objCom.Parameters.Add(objSqlParam_Designation);
                objCom.Parameters.Add(objSqlParam_Department);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                employeeAdded = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HRDSException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return employeeAdded;
        }

        public bool UpdateEmployeeDAL(Employee objEmployee)
        {
            bool employeeUpdated = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HRDSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009519].[UpdateEmployee_9519]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Id = new SqlParameter("@ID", objEmployee.Id);
                SqlParameter objSqlParam_Name = new SqlParameter("@Name", objEmployee.Name);
                SqlParameter objSqlParam_Designation = new SqlParameter("@Designation", objEmployee.Designation);
                SqlParameter objSqlParam_Department = new SqlParameter("@Department", objEmployee.Department);
                //
                objCom.Parameters.Add(objSqlParam_Id);
                objCom.Parameters.Add(objSqlParam_Name);
                objCom.Parameters.Add(objSqlParam_Designation);
                objCom.Parameters.Add(objSqlParam_Department);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                employeeUpdated = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HRDSException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return employeeUpdated;
        }

        public bool DeleteEmployeeDAL(int id)
        {
            bool employeeDeleted = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HRDSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009519].[DeleteEmployee_9519]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Id = new SqlParameter("@ID", id);
                //
                objCom.Parameters.Add(objSqlParam_Id);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                employeeDeleted = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new HRDSException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return employeeDeleted;
        }

        public Employee SearchEmployeeDAL(int id)
        {
            Employee objEmployee = null;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HRDSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009519].[SearchEmployee_9519]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_Id = new SqlParameter("@ID",SqlDbType.Int);
                SqlParameter objSqlParam_Name = new SqlParameter("@Name", SqlDbType.VarChar, 50);
                SqlParameter objSqlParam_Designation = new SqlParameter("@Designation", SqlDbType.Int);
                SqlParameter objSqlParam_Department = new SqlParameter("@Department", SqlDbType.Int);
                //
                objSqlParam_Id.Direction = ParameterDirection.Input;
                objSqlParam_Name.Direction = ParameterDirection.Output;
                objSqlParam_Designation.Direction = ParameterDirection.Output;
                objSqlParam_Department.Direction = ParameterDirection.Output;
                //
                objCom.Parameters.Add(objSqlParam_Id);
                objCom.Parameters.Add(objSqlParam_Name);
                objCom.Parameters.Add(objSqlParam_Designation);
                objCom.Parameters.Add(objSqlParam_Department);
                //
                objSqlParam_Id.Value = id;
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                objEmployee = new Employee();
                objEmployee.Id = id;
                objEmployee.Name = objSqlParam_Name.Value as string;
                objEmployee.Designation = Convert.ToInt32(objSqlParam_Designation.Value);
                objEmployee.Department = Convert.ToInt32(objSqlParam_Department.Value);
            }
            catch (SqlException objSqlEx)
            {
                throw new HRDSException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objEmployee;
        }

        public List<Employee> GetAllEmployeesDAL()
        {
            List<Employee> objEmployees = new List<Employee>();
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HRDSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009519].[GetAllEmployees_9519]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                while (objDR.Read())
                {
                    Employee objEmployee = new Employee();
                    objEmployee.Id = Convert.ToInt32(objDR[0]);
                    objEmployee.Name = objDR[1] as string;
                    objEmployee.Designation = Convert.ToInt32(objDR[2]);
                    objEmployee.Department = Convert.ToInt32(objDR[3]);
                    objEmployees.Add(objEmployee);
                }
            }
            catch (SqlException objSqlEx)
            {
                throw new HRDSException(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return objEmployees;
        }

        public DataTable GetDesignationsDAL()
        {
            DataTable designationList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HRDSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009519].[GetDesignations_9519]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                designationList = new DataTable();
                designationList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new HRDSException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return designationList;
        }

        public DataTable GetDepartmentsDAL()
        {
            DataTable departmentList = null;
            SqlConnection objCon = null;
            try
            {

                objCon = new SqlConnection(
                    ConfigurationManager.ConnectionStrings["HRDSConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009519].[GetDepartments_9519]", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                objCon.Open();
                SqlDataReader objDR = objCom.ExecuteReader();
                departmentList = new DataTable();
                departmentList.Load(objDR);
            }
            catch (SqlException ex)
            {
                throw new HRDSException(ex.Message);
            }
            finally
            {
                objCon.Close();
            }
            return departmentList;
        }
    }
}
